Thank you for downloading this font. It was created by Gaston Yagmourian. You are free to use it, as long as you send me email telling me you liked it.

This font is at an early stage in the production process, so some characters might be missing, or kerning can be off. I'm not responsible for any problems that can arise form their use.

--

Gracias por bajar esta fuente a tu computadora. Fue crada por Gaston Yagmourian. Esta tipograf�a es gratis, siempre y cuando me cuentes que la estas usando via email.

Esta fuente est� en una de las primeras etapas de producci�n, as� que algunos caracteres pueden faltar, o el interletraje estar fuera de lugar. No me hago responsable por problemas que puedan ocurrir de su uso.

--

Gaston Yagmourian, 1997.

e-mail: GastonY@ibm.net
web: http://tausystems.com/gaston
