TrueTypeFont: Padaloma (italic)
Dennis Ludlow Productions 2002 all rights reserved
Sharkshock Productions
email: maddhatter_dl@yahoo.com

Hey everyone. Just another creamy font I'm throwing out for all you ice cream lovers.
Feel free to distribute but contact me if you'd like to use this or any of my fonts commercially. 
Hope you enjoy.

check out my graphic archive and fonts at www.sharkshock.com
                                  "because boring design SUCKS!"