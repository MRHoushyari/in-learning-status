Head-injuries
Made 05:30 2001-01-26

-----------------------------*

more info, faq and so on:
www.mrfisk.com
fonts.mrfisk.com

-----------------------------*

you should say thanks
letters@mrfisk.com

-----------------------------*

Thankyou.
MR.FISK