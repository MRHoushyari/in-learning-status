Dark Garden (�Michal Kosmulski) Font (version 0.9)

The Dark Garden font was created by Michal Kosmulski using CorelDraw 4. The font is freeware and may be distributed in all possible ways as long as this message is included.

This is a pre-release 0.9 version, wchich contains only the 26 letters of the English alphabet. Future versions will include Polish and German characters as well as digits.

Note: this font looks best at large font sizes. For screen display, a size of at least 72 points is recommended.

The author makes no guarantee about the viablity and usability of this font and is not responsible for any damage related to its use.

Copyright 1999 by Michal Kosmulski
http://hermes.umcs.lublin.pl/users/kosmulsk/michal/index.htm
