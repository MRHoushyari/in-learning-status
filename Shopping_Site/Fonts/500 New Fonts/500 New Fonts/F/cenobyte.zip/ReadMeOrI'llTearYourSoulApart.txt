CENOBYTE
True Type Font by Chad Savage
savagevision@hotmail.com

Freeware: Please distribute this text file with the font.
Font created in Illustrator 7, rasterized in Photoshop, traced in Streamline, and fontified with Fontographer. AI7 EPS files suck!

Witness the Sinister Visions of Chad Savage at http://www.gothic.net/~savage/ for more free fonts, icons, and stuff.