yeah yeah...
the obligatory readme file. ok, here's the story... 
i know that this is just a simple grunge font by 
someone who doesn't have the best penmanship
skills. but you know, it took me a bit of effort to 
create this and make it available for you, the
darling consumer. i'm asking a measly ten bucks for
this font. if you're a decent kinda soul you can
mail ten bucks {or a creative equivolent} to:

   Matt Coburn
   P.O. Box 347
   Norwich, CT
   06360-0347

If your're strapped, hey, that's cool. I understand.
In that case, slap a 20� stamp on a freaking post 
card and my dogma won't be chasing your karmha.

If you use this font on your site {even if that does
strike me as a ghastly idea} let me know so i can swing 
by and take a look at it. if you use this font 
commercially, your ass had better pay the ten bucks!

nuff said.

-Matt Coburn              
[][][][][][][][][][][]
http://bigmisterc.com 
http://orpheuszine.com
m@bigmisterc.com      