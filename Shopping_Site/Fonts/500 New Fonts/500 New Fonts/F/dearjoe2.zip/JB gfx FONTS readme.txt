J O E B O B graphics 2005

Fontlovers everywhere,

the JOEBOB graphics fonts are all freeware for personal use, but 
if you want to use them for commercial purposes, you have to 
notice me and/ or send an example of the work you've used them for.

Only exceptions are the 'dearJoe' fonts, which are shareware; you 
can download them for free to check them out, but if you want to 
use 'em you'll have to pay for a users-licence.

Even though I make these font available as freeware for personal use,
they may not be re-distributed on any media, they may not be sold,  
they may not be renamed or converted and they may not be made available
for download on any web page/ftp site without my permission.

E-mail me and ask for my permission, which you'll probably get.

I shall, in no event, be liable for any damages arising out of use of this font.


And now go on and enjoy the font.


J O E B O B grpahics
www.joebob.nl

info@joebob.nl