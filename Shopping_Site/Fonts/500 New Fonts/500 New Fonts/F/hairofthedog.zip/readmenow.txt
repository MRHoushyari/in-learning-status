Hey fontmonglers and biffs..this iz hair  of the  dog

Ya have de'unleuded a font from da speziale font metropol - the world.
Ho' do ya like it?? ey? ver'y goody goody or bad..
If you wanna use 'it on da homepaigee of your'ss - tell me. I wanna gaze at it.

This iz a spezial-font, I want money for it. But I dont think you got any
so just send me a email and tell me u will use it for.

 |-------------------*  Frequently Asked Questions : *----------------|
   
   � Can I use the fonts for commercial things, such as things I might
     get money for? Can I buy the font/fonts?

   � No!! If you want to do that you'll have to contact me first and
     get my permission. And we must set a deal, how much money I can
     earn from it. You can buy the font, it will cost between $10 - 
     $20 then you'll have the full rights to it.

 |--------------------------------------------------------------------|

   � Can I use the fonts on my webpage?

   � Yes, if it's a free webpage. If you aint making any money thru
     it, that means if you make a clickthru banner etc, with my font
     on it, you are making money thru my font. It have to free all 
     over or else it's not allowed.

 |--------------------------------------------------------------------|

   � Can I put up the font-file/files for download on my page?

   � Yes you can. But you'll have to leave the file as it is, ex
     if the fontfile name is something2000mg.zip you'll have to 
     leave it that way. And it MUST include all original files such
     as the .ttf file and the readme.txt file + other. You cant
     change anything inside them, or else its not allowed. And you
     have to write a link next to the file where you downloaded it,
     that it is taken from MR.FISK FONTS - http://fonts.mrfisk.com

 |--------------------------------------------------------------------|

   � Can I include the fontfiles on a cd-rom wich I am going to sell?

   � No!! You'll have to contact me first and get my permission. Its 
     the same laws as question nr 1 in this faq.

 |--------------------------------------------------------------------|

   � So you dont want anything for the fonts I download?

   � Yes I do. When you have installed the font/fonts you'll have to
     write me a proper Thank You mail, because this is not freeware
     its Letterware. Or you can write something nice in my guestbook.

 |--------------------------------------------------------------------|

   � Any other questions regarding what fontrules are on and off,
     write to: fonts@mrfisk.com

 |--------------------------------------------------------------------| 
email: fonts@mrfisk.com
or
       fonts@undergroundstar.nu

take care u

www.mrfisk.com
www.undergroundstar.nu

------------------------------------------------------------------------------
