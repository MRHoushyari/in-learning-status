
DISTURBED.COM FREEFONT:          JANIS

This font is Copyright 2001 Matt Petty of www.disturbed.com.  If you wish to redistribute this font from the World Wide Web, I require a text hyperlink to www.disturbed.com next to the download of the font.  

For more sexy alphabets, visit http://www.disturbed.com

Rock on!