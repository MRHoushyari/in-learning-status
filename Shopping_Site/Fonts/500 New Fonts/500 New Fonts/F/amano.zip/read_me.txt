This font is freeware for personal use; if you use it in a commercial project or product, contact me at noticies@my-deja.com to agree on a license fee according the use you make.
If you want to know more about Joan Mas' fonts, and get more freeware fonts, illustrations and other stuff, visit his home page at http://teleline.terra.es/personal/joanmmas/

If you produce some creative material using my fonts or illustrations, please send an e-mail message to noticies@my-deja.com , telling where and how you're using them. We will be pleased to take a look and put a link back to your pages at my site.

You can redistribute these fonts as long as you charge nothing to receive them. 


Enjoy it!