# RTL Bootstrap

rtl Bootstrap for right-to-left languages such as Persian & Arabic. available versions: 4.1.3 & 3.37

- There is no changes in bootstrap base attributes!
- For Bootstrap 5 just check Bootstrap website -> https://getbootstrap.com/docs/5.1/getting-started/rtl


<div dir="rtl">

## بوت استرپ راستچین
فریم ورک راستچین شده بوت استرپ نسخه های 4.1.3 و 3.37

- تغییری در ویژگی های اصلی بوت استرپ داده نشده و تنها راستچین سازی شده است
- برای بوت استرپ راست چین شده ورژن 5 و جدیدتر سری به سایت اصلی بوت استرپ بزنید https://getbootstrap.com/docs/5.1/getting-started/rtl 
</div>
